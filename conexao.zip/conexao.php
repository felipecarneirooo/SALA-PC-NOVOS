<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "senac";

//Mysql
//MYsqli
//PDO objeto de dados php

//Criar conexao
$con = mysqli_connect($servername, $username, $password, $dbname);
//Verifica conexao
if (!$con){
    die("Erro na conexao: " . mysqli_connect_erro());
}
echo "Conectado com sucesso!";

?>

</body>
</html>