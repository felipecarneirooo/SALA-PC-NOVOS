<?php

$y = 0;
while ($y < 50) {
    $y++;
    echo "Estou aprendendo loopings 100 vezes no PHP<br>";
}

?>