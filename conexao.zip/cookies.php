<!DOCTYPE html>
<html lang="pt">

<?php

$cookie_nome = "user";
$cookie_valor = "Joao";
setcookie($cookie_nome, $cookie_valor, time() + (86400 * 30), "/"); //86400 = 1 dia

?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php

if (!isset($_COOKIE[$cookie_nome])){
    echo "Cookie" . $cookie_nome . " nao configurado";
} else {
    echo "Cookie" . $cookie_nome . "configurado<br>";
    echo "Valor do cookie: " . $_COOKIE[$cookie_nome];
}

?>
    
</body>
</html>