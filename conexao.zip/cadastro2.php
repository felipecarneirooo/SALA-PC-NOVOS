<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cadastro2</title>
</head>
<body>
    
<form action="fim_do_cadastro.php" method="post">
        Senha: <input type="password" name="senha" required minlength="5"<br><br><br>
        Comentario: <br><textarea name="comentario" cols="30" rows="6"></textarea><br>

        <input type="hidden" name="nome" value="<?php echo $_POST['nome']; ?>">
        <input type="hidden" name="sexo" value="<?php echo $_POST['sexo']; ?>">
        
        <input type="submit" value="finalizar cadastro">

       
</form>
</body>
</html>