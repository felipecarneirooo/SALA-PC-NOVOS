<?php

$mensagem = 5;
switch ($mensagem) {
    case 1:
        echo "uma bicicleta";
        break;

        case 2:
            echo "20 mil em barras de ouro";
            break;

            case 3:
                echo "uma casa";
                break;

                case 4:
                    echo "uma conjunto de panelas";
                    break;

                    case 5:
                        echo "uma carro zero";
                        break;

                        case 6:
                            echo "parabens seu premio foi: ";
                            break;
    
    default:
        echo "nenhum premio definido para este valor.";
        break;
}
?>