<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname ="meubd";

//criar PDO dbname
try{
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // config PDO modo erro
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "CREATE TABLE Myguests (id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    firstname VARCHAR(30) NOT NULL, lastname VARCHAR(30) NOT NULL, email VARCHAR(50),
    reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)";


    $pdo->exec($sql);
    echo "Criado com sucesso minha TABELA";

    
} catch(PDOException $e){
    echo $sql . "<br>" . $e->getMessage();
}
  
//fechar porta de acesso
//mysqli $conn->close();
$pdo = null;
?>

</body>
</html>