<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>fim do cadastro</title>
</head>
<body>
    
<?php
    echo "Nome: " . htmlspecialchars($_POST['nome']) . "<br>";
    echo "Sexo: " . htmlspecialchars($_POST['sexo']) . "<br>";
    echo "Senha: " . htmlspecialchars($_POST['senha']) . "<br>";
    echo "Comentario: " . htmlspecialchars($_POST['comentario']) . "<br>";
?>
</body>
</html>