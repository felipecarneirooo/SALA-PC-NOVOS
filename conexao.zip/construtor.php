<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php

class fruta {
    public $name;
    public $color;

    function __construct($name){
        $this->name = $name;
    }

    function get_name(){
        return $this->name;
    }
    
}

$apple = new fruta("Apple");
echo $apple->get_name();

?>

</body>
</html>