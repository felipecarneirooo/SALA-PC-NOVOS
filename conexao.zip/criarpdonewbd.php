<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php
$host = 'localhost';
$username = 'root';
$password = '';

//criar PDO dbname
try{
    $pdo = new PDO("mysql:host=$host;", $username, $password);
    // config PDO modo erro
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "CREATE DATABASE jecao";
    $pdo->exec($sql);
    echo "Criado com sucesso meu DB";

    
} catch(PDOException $e){
    echo $sql . "<br>" . $e->getMessage();
}
  
//fechar porta de acesso
//mysqli $conn->close();
$pdo = null;
?>

</body>
</html>