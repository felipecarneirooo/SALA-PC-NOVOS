<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cadastro2</title>
</head>
<body>
    
<form action="cadastro2.php" method="post">
        Nome: <input type="text" name="nome" required pattern=".*\s+.*"<br><br><br>
        Sexo:
        <input type="radio" name="sexo" value="masculino" required> masculino
        <input type="radio" name="sexo" value="feminino" required> feminino<br><br>
        <input type="submit" value="Proximo">

       
</form>
</body>
</html>