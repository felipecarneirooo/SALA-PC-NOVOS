<?php

$estado = array("Brasilia", 64, "", "Taguatinga", "Ceilandia");
var_dump($estado);

?>