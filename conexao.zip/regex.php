<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <?php
    //regex preg_mach
    $tr = "Visite o SENAC";
    $pat = "/SENAC/";
    echo preg_match($pat, $tr);
    echo "<br>";

    $tatu="Visite o windows";echo "<br>";
    $pato="/WINDOWS/i";
    echo preg_replace($pato, "WINDOWS", $tatu);echo "<br>";
    echo "<br>";
    //DATA
    date_default_timezone_set("America/Sao_Paulo");
    echo "hoje e " . date ("y/m/d") . "<br>"; echo "<br>";
    echo "hoje e " . date ("1") . "<br>";echo "<br>";
    echo "hoje e " . date ("y-m-d") . "<br>";echo "<br>";
    echo date ("y") . "<br>";echo "<br>";
    echo "hora " . date ("h:i:sa") . "<br>";
   
    $age = array("Peter"=>35, "Ben"=>37, "Paulo"=>43);
    echo "<br>";
    echo json_encode($age);

    $ag = array("Peter"=>35, "Ben"=>37, "Paulo"=>43);
    echo "<br>";
    $obj = json_encode($ag);
    $obj = json_decode($obj);echo "<br>";
    echo $obj->Ben;
    echo $obj->Paulo;

?>

</body>
</html>