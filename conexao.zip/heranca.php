<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    class fruta {
        public $name;
        public $color;

        function _construtor($name, $color){
            $this->name = $name;
            $this->color = $color;
        }

public function intro(){
    echo "a fruta e {$this->name} e a cor e {$this->color} .";
}
    
    }

    class morango extends fruta{
         public function message(){
            echo "eu sou uma fruta?";echo "<br>";echo "<br>";   	
        }
    };

    $morango = new morango("morango", "vermelho");
    $morango->message();
    $morango->intro();
    
    
?>

</body>
</html>